Pari huomioo;

- HTML löytyy Main-kansiosta

- Mobiili menu erilainen kuin leiskassa, mun mielestä se on näin
hieman enemmän "user friendly"

- Tähtäin sivun rullausta en saa toimimaan, se varmaan pitäisi
toteuttaa niin että sivun "content" on sticky sivun "containerin"
sisällä, samanlaisti kuin vika sivu. Se ei vaan onnistu.